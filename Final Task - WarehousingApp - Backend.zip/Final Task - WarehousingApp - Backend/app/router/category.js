const expressAsyncHandler = require("express-async-handler");

const {
  CategoryController,
} = require("../http/controllers/category.controller");

const router = require("express").Router();

router.get(
  "/list",
  expressAsyncHandler(CategoryController.getListOfCategories)
);

router.get("/:id", expressAsyncHandler(CategoryController.getCategoryById));

router.get("/:id", expressAsyncHandler(CategoryController.checkExistCategory));

router.get(
  "/:englishTitle",
  expressAsyncHandler(CategoryController.findCategoryWithTitle)
);

router.post("/add", expressAsyncHandler(CategoryController.addNewCategory));

router.patch(
  "/update/:id",
  expressAsyncHandler(CategoryController.updateCategory)
);

router.delete("/:id", expressAsyncHandler(CategoryController.removeCategory));

module.exports = {
  categoryRoutes: router,
};
