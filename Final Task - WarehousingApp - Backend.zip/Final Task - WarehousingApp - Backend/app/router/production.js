const expressAsyncHandler = require("express-async-handler");
const {
  ProductionController,
} = require("../http/controllers/production.controller");
const { ROLES } = require("../../utils/constants");
const { authorize } = require("../http/middlewares/permission.guard");

const router = require("express").Router();

router.get(
  "/list",
  expressAsyncHandler(ProductionController.getListOfProductions)
);
router.get(
  "/productions",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.getListOfOwnerProductions)
);
router.post(
  "/add",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.addNewProduction)
);
router.get(
  "/:id",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.getProductionById)
);
router.patch(
  "/update/:id",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.updateProduction)
);
router.patch(
  "/:id",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.changeProductionStatus)
);
router.delete(
  "/:id",
  //authorize(ROLES.ADMIN, ROLES.OWNER),
  expressAsyncHandler(ProductionController.deleteProduction)
);

module.exports = {
  productionRoutes: router,
};
