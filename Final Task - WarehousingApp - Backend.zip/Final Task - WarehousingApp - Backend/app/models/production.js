const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const ProductionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    quantity: { type: Number, required: true },
    price: { type: Number, required: true },
    category: { type: ObjectId, ref: "Category", required: true },
  },
  {
    timestamps: true,
  }
);

module.exports = {
  ProductionModel: mongoose.model("Production", ProductionSchema),
};
