const Controller = require("./controller");
const { StatusCodes: HttpStatus } = require("http-status-codes");
const mongoose = require("mongoose");
const { CategoryModel } = require("../../models/category");
const { ProductionModel } = require("../../models/production");
const createHttpError = require("http-errors");
const { addProductionSchema } = require("../validators/production.schema");
const { ProposalModel } = require("../../models/proposal");
const ObjectId = mongoose.Types.ObjectId;

class ProductionController extends Controller {
  async addNewProduction(req, res) {
    //const userId = req.user._id;
    await addProductionSchema.validateAsync(req.body);
    const { title, quantity, price, category } = req.body;

    const production = await ProductionModel.create({
      title,
      quantity,
      price,
      category,
    });

    if (!production?._id)
      throw createHttpError.InternalServerError("محصول ثبت نشد");

    return res.status(HttpStatus.CREATED).json({
      statusCode: HttpStatus.CREATED,
      data: {
        message: "محصول با موفقیت ایجاد شد",
        production,
      },
    });
  }

  async getListOfProductions(req, res) {
    let dbQuery = {};
    const { search, category, sort } = req.query;

    // SEARCH
    if (search) dbQuery["$text"] = { $search: search };

    // // STATUS
    // if (["OPEN", "CLOSED"].includes(status)) {
    //   dbQuery["status"] = { $eq: status };
    // }

    // CATEGORY
    if (category && !category.includes("ALL")) {
      const categories = category.split(",");
      const categoryIds = [];
      for (const item of categories) {
        const category = await CategoryModel.findOne({ englishTitle: item });
        if (category) categoryIds.push(category._id);
      }
      dbQuery["category"] = {
        $in: categoryIds,
      };
    }

    // SORT
    const sortQuery = {};
    if (!sort) sortQuery["createdAt"] = 1;
    if (sort) {
      if (sort === "latest") sortQuery["createdAt"] = -1;
      if (sort === "earliest") sortQuery["createdAt"] = 1;
    }

    const productions = await ProductionModel.find(dbQuery)
      .select({
        owner: 0,
        freelancer: 0,
        proposals: 0,
      })
      .populate([{ path: "category", select: { title: 1, englishTitle: 1 } }])
      .sort(sortQuery);

    return res.status(HttpStatus.OK).json({
      statusCode: HttpStatus.OK,
      data: {
        productions,
      },
    });
  }

  async getListOfOwnerProductions(req, res) {
    let dbQuery = {};
    const user = req.user;
    dbQuery.owner = user._id;

    const { search, category, sort } = req.query;

    if (search) dbQuery["$text"] = { $search: search };
    if (category) {
      const categories = category.split(",");
      const categoryIds = [];
      for (const item of categories) {
        const { _id } = await CategoryModel.findOne({ englishTitle: item });
        categoryIds.push(_id);
      }
      dbQuery["category"] = {
        $in: categoryIds,
      };
    }

    const sortQuery = {};
    if (!sort) sortQuery["createdAt"] = 1;
    if (sort) {
      if (sort === "latest") sortQuery["createdAt"] = -1;
      if (sort === "earliest") sortQuery["createdAt"] = 1;
      if (sort === "popular") sortQuery["likes"] = -1;
    }

    const productions = await ProductionModel.find(dbQuery)
      .populate([
        { path: "category", select: { title: 1, englishTitle: 1 } },
        { path: "owner", select: { name: 1 } },
        { path: "freelancer", select: { name: 1 } },
      ])
      .sort(sortQuery);

    return res.status(HttpStatus.OK).json({
      statusCode: HttpStatus.OK,
      data: {
        productions,
      },
    });
  }

  async getProductionById(req, res) {
    const { id } = req.params;
    await this.findProductionById(id);
    const production = await ProductionModel.findById(id).populate([
      {
        path: "category",
        model: "Category",
        select: {
          title: 1,
          englishTitle: 1,
        },
      },
      {
        path: "proposals",
        model: "Proposal",
        populate: [
          {
            path: "user",
            model: "User",
            select: { name: 1 },
          },
        ],
      },
      {
        path: "owner",
        model: "User",
        select: { name: 1 },
      },
      {
        path: "freelancer",
        model: "User",
        select: { name: 1 },
      },
    ]);

    return res.status(HttpStatus.OK).json({
      statusCode: HttpStatus.OK,
      data: {
        production,
      },
    });
  }

  async findProductionById(id) {
    if (!mongoose.isValidObjectId(id))
      throw createHttpError.BadRequest("شناسه محصول ارسال شده صحیح نمیباشد");
    const production = await ProductionModel.findById(id);
    if (!production) throw createHttpError.NotFound("محصول یافت نشد.");
    return production;
  }

  async changeProductionStatus(req, res) {
    const { id } = req.params;
    const { status } = req.body;

    const updateResult = await ProductionModel.updateOne(
      { _id: id },
      { $set: { status } } // 0, 1, 2
    );

    if (updateResult.modifiedCount === 0)
      throw createHttpError.InternalServerError(" وضعیت پروپوزال آپدیت نشد");

    let message = "محصول بسته شد";
    if (status === "OPEN") message = "وضعیت محصول به حالت باز تغییر یافت";

    return res.status(HttpStatus.OK).json({
      statusCode: HttpStatus.OK,
      data: {
        message,
      },
    });
  }

  async deleteProduction(req, res) {
    const { id } = req.params;
    const production = await this.findProductionById(id);

    if (production.freelancer)
      throw createHttpError.BadRequest("محصول قابل حذف نیست");

    const result = await ProductionModel.deleteOne({ _id: id });
    if (result.deletedCount)
      return res.status(HttpStatus.OK).json({
        statusCode: HttpStatus.OK,
        data: {
          message: "محصول با موفقیت حذف شد",
        },
      });
  }

  async updateProduction(req, res) {
    const { id } = req.params;
    await this.findProductionById(id);

    const { title, quantity, price, category, updatedAt } = req.body;

    console.log(req.body);

    await addProductionSchema.validateAsync(req.body);

    const updateResult = await ProductionModel.updateOne(
      { _id: id },
      {
        $set: { title, quantity, price, category, updatedAt },
      }
    );

    if (updateResult.modifiedCount == 0)
      throw createError.InternalServerError("به روزرسانی محصول انجام نشد");

    return res.status(HttpStatus.OK).json({
      statusCode: HttpStatus.OK,
      data: {
        message: "به روز رسانی محصول با موفقیت انجام شد",
      },
    });
  }
}

module.exports = {
  ProductionController: new ProductionController(),
};
